from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
import requests
import time


app = Flask(__name__)
socketio = SocketIO(app)

API_KEY = '0d06cce4dde6f1e4d0dccced'
API_URL = f'https://v6.exchangerate-api.com/v6/{API_KEY}/latest/'
CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'AUD', 'CAD', 'SGD', 'CHF', 'MYR', 'JPY', 'CNY']

@app.route('/')
def index():
    return render_template('index.html', currencies=CURRENCIES)

@app.route('/convert', methods=['POST'])
def convert():
    from_currency = request.form['from_currency']
    to_currency = request.form['to_currency']
    amount = float(request.form['amount'])
    response = requests.get(f'{API_URL}{from_currency}')
    data = response.json()
    if response.status_code != 200 or 'conversion_rates' not in data:
        return "Error: Unable to fetch conversion rates."
    conversion_rate = data['conversion_rates'].get(to_currency)
    if not conversion_rate:
        return "Error: Invalid target currency."
    converted_amount = amount * conversion_rate
    return render_template('result.html', converted_amount=converted_amount, from_currency=from_currency, to_currency=to_currency, amount=amount)

def fetch_real_time_data():
    while True:
        for currency in CURRENCIES:
            response = requests.get(f'{API_URL}{currency}')
            data = response.json()
            if response.status_code == 200 and 'conversion_rates' in data:
                socketio.emit('update_data', {'currency': currency, 'rates': data['conversion_rates']})
        time.sleep(5)

@socketio.on('connect')
def handle_connect():
    print('Client connected')

if __name__ == '__main__':
    socketio.start_background_task(fetch_real_time_data)
    socketio.run(app, debug=True)
